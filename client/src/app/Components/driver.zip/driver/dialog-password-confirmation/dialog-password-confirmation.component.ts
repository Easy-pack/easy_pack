import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-password-confirmation',
  templateUrl: './dialog-password-confirmation.component.html',
  styleUrls: ['./dialog-password-confirmation.component.css']
})
export class DialogPasswordConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
